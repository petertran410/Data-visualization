function addEltToSVG(svg, name, attrs) {
    var element = document.createElementNS("http://www.w3.org/2000/svg", name);
    if (attrs === undefined) attrs = {};
    for (var key in attrs) {
        element.setAttributeNS(null, key, attrs[key]);
    }
    svg.appendChild(element);
}

function createHistogram(svgElement, str) {
    // remove existing content in SVG element
    svgElement.innerHTML = '';

    // define the six bins and set counts = 0
    const bins = [
        { label: 'A-D', count: 0 },
        { label: 'E-H', count: 0 },
        { label: 'I-L', count: 0 },
        { label: 'M-P', count: 0 },
        { label: 'Q-U', count: 0 },
        { label: 'V-Z', count: 0 },
    ];

    // loop the string and count for the appropriate bin
    for (let i = 0; i < str.length; i++) {
        const charCode = str.toUpperCase().charCodeAt(i);
        if (charCode >= 65 && charCode <= 68) {
            bins[0].count++;
        } else if (charCode >= 69 && charCode <= 72) {
            bins[1].count++;
        } else if (charCode >= 73 && charCode <= 76) {
            bins[2].count++;
        } else if (charCode >= 77 && charCode <= 80) {
            bins[3].count++;
        } else if (charCode >= 81 && charCode <= 85) {
            bins[4].count++;
        } else if (charCode >= 86 && charCode <= 90) {
            bins[5].count++;
        }
    }

    // calculate the max count to determine the scale factor for the bars
    const maxCount = Math.max(...bins.map(bin => bin.count));
    const barHeight = 350;

    // loop through the bins and add a rectangle to the SVG element for each
    for (let i = 0; i < bins.length; i++) {
        const bin = bins[i];
        const x = i * 50;
        const y = barHeight * (1 - bin.count / maxCount);
        const width = 50;
        const height = barHeight * (bin.count / maxCount);

        const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        rect.setAttribute('x', x);
        rect.setAttribute('y', y);
        rect.setAttribute('width', width);
        rect.setAttribute('height', height);
        rect.setAttribute('fill', 'blue');
        rect.setAttribute('stroke', 'black');

        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', x + width / 2);
        text.setAttribute('y', barHeight + 20);
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('fill', 'black');
        text.textContent = bin.label;

        svgElement.appendChild(rect);
        svgElement.appendChild(text);
    }
}

//Bar Chart
function createBarChart(svgElement,dataset) {
    svgElement.innerHTML = "";

    function getColor(d) {
        const blueValue = 0 + (d * 5);
        return `rgb(0, 0, ${blueValue})`;
    }

    // Initilize margin
    var svg = d3.select("#bar_chart"),
        width = svg.attr("width"),
        height = svg.attr("height");

    // Create dynamic bars
    // Describe the width and height of the bars
    svg.selectAll(".bar")
        .data(dataset)
        .enter()
        .append("rect")
        .attr("x", function (d, i) { return i * (width / dataset.length); })
        .attr("y", function (d) { return height - (d * 3); })
        .attr("width", width / dataset.length - 2)
        .attr("height", function (d) { return d * 3; })
        .style("fill", function (d) { return getColor(d); })


    svg.selectAll("text")
        .data(dataset)
        .enter()
        .append("text")
        .text(function (d) {
            return d;
        })
        .attr("text-anchor", "middle")
        .attr("x", function (d, i) {
            return i * (width / dataset.length) + (width / dataset.length - 2) / 2;
        })
        .attr("y", function (d) {
            return height - (d * 3) + 10;
        })
        .attr("font-family", "sans-serif")
        .attr("font-size", 12)
        .attr("fill", "#ffffff")
}
//histogram of the above data set
function createHisto(svgElement, dataset) {
    svgElement.innerHTML = "";

    function getColor(rate) {
        // Define a color scale with distinct colors
        const colorScale = d3.scaleSequential(d3.interpolateViridis)
            .domain([0, 1]); // Range from 0 to 1
        // Get the color based on the rate
        return colorScale(rate);
    }
    
    // Set the dimensions of the histogram
    var width = 500;
    var height = 400;
    var numberOfBins = 10;

    // Calculate the bin width
    var binWidth = (d3.max(dataset) - d3.min(dataset)) /numberOfBins;

    // Create the SVG element
    var svg = d3.select("#histogram_2")
        .attr("width", width)
        .attr("height", height + 20)
        .attr("transform",
            "translate(" + 0 + "," + 0 + ")")
        .style("overflow", "initial");

    // Create the histogram layout with equal-width bins
    var histogram = d3.histogram()
        .domain([d3.min(dataset), d3.max(dataset)])
        .thresholds(d3.range(d3.min(dataset), d3.max(dataset) + binWidth, binWidth));

    // Compute the bins and frequencies
    var bins = histogram(dataset);

    // Define the scales for the histogram
    var xScale = d3.scaleLinear()
        .domain([d3.min(dataset), d3.max(dataset)])
        .range([0, width]);

    var yScale = d3.scaleLinear()
        .domain([0, d3.max(bins, function (d) { return d.length; })])
        .range([height, 0]);

    // Create the bars for the histogram
    var bars = svg.selectAll(".bar")
        .data(bins)
        .enter()
        .append("rect")
        .attr("class", "bar")
        .attr("x", function (d) { return xScale(d.x0); })
        .attr("y", function (d) { return yScale(d.length); })
        .attr("width", function (d) { return xScale(d.x1) - xScale(d.x0) - 1.5; })
        .attr("height", function (d) { return height - yScale(d.length); })
        .style("fill", function (d) {
            const rate = d.length / dataset.length;
            return getColor(rate);
        });

    // Add the x-axis
    var xAxis = d3.axisBottom(xScale);
    svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis);

    // Add the y-axis
    var yAxis = d3.axisLeft(yScale);
    svg.append("g")
        .attr("class", "y axis")
        .call(yAxis);
}

const dataset = Array.from({ length: 20 }, () => Math.floor(5 + Math.random() * 51));
createBarChart(document.querySelector("#bar_chart"),dataset);
createHisto(document.querySelector("#histogram_2"),dataset);
createHistogram(document.querySelector("#histogram"), "Nguyen Thanh Hien");



